<?php
   class user_test extends CI_Controller
   {
      function __construct()
	  {
	     parent::__construct();
		 $this->load->helper('html');
		 $this->load->helper('url');
		 $this->load->helper('form');
		 $this->load->library('form_validation');
	   }
       function index()
       {
          $this->form_validation->set_rules('username','Username','required');
          $this->form_validation->set_rules('userpass','Password','required|min_length[8]|max_length[12]');
		  $this->form_validation->set_rules('userpass1','Confirm Password','required|min_length[8]|matches[userpass]|max_length[12]');
		  $this->form_validation->set_rules('useremail','Email Address','required|valid_email');
		  $this->form_validation->set_rules('address','Address','required');
		  if($this->form_validation->run()==false)
		  {
			  $this->load->view('user');
		  }
		  else
		  {
			  if($this->input->post('Register'))
			  {
				  $uid=$this->input->post('username');
				  $path='uploads/'.$uid;
				  if(!is_dir($path))
				  {
                    mkdir($path,'0777',true);
				  }	
				  $config['upload_path']=$path;
				  echo $config['upload_path'];
				  $config['allowed_types']='gif|jpg|png';
				  /*$config[
			  }
		  }
	   }
   }   
?>