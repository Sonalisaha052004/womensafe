<?php
   class User1 extends CI_Controller
   {
      function __construct()
	  {
	     parent::__construct();
		 $this->load->helper('html');
		 $this->load->helper('url');
		 $this->load->helper('form');
	  }
	  function index()
	  {
	    $this->load->view('Login');
	  }
	  function login_check()
	  {
	    if($this->input->post('html')
		{
		    $name=$this->input->post('user_name');
			$pass=$this->input->post('password');
			$data=array('name'=>$name,'pass'=>$pass);
			$this->load->view('mssg',$data);
		}
	  }
    }
?>	
		 