<?php
    class imagetest extends CI_Controller
	{
	  function __construct()
	  {
	    parent::__construct();
		$this->load->helper('html');
		$this->load->helper('url');
		$this->load->helper('form');
	  }
	  function index()
	  {
	    $this->load->view('img');
	  }
?>