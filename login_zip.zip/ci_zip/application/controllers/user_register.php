<?php
   class user_register extends CI_Controller
   {
     function __construct()
	 {
	   parent::__construct();
	   $this->load->helper('html');
	   $this->load->helper('url');
	   $this->load->helper('form');
	 }
     function index()
     {
       $this->load->view('register');
     }
	 function register_check()
	 {
		 if($this->input->post('register'))
		 {
			 $name=$this->input->post('user_name');
			 $pass=$this->input->post('password');
			 $hobbies=$this->input->post('Hobbies');
			 $ploc=$this->input->post('ploc');
			 $str1=implode($hobbies,",");
			 $str2=implode($ploc,",");
			 $data=array('name'=>$name,'pass'=>$pass,'hobbies'=>$str1,'ploc'=>$str2);
			 $this->load->view('msg_register',$data);
		 }
	 }
			 
   }
?>  
	   