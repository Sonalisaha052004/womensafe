<?php
    class SampleProgram3 extends CI_Controller
	{
	   var $x1;
	   function __construct()
	   {
	     parent::__construct();
		 $this->x1=2000;
	   }
	   function index()
	   {
	     $asoarr1['Srinjoyee']=$this->x1;
		 $this->load->view('SampleView2',$asoarr1);
		}
	}
?>		