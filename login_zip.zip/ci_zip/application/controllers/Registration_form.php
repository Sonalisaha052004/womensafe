<?php
   class Registration_form extends CI_Controller
   {
     public function index()
	 {
	    $this->load->helper('html');
		$this->load->helper(array('form','url'));
		$this->load->view('Registration');
		$this->load->database();
	 }
     function savingdata()
     {
       $data=array('Enter name'=>$this->input->post('Name'),
                   'Enter Password'=>$this->input->post('Password'),
                   'Enter Address'=>$this->input->post('Address'),
				   'Gender'=>$this->input->post('gender'),
				   'Course Applied For'=>$this->input->post('course_name'),
				   'Center'=>$this->input->post('center'),
				   'Bio-data'=>$this->input->post('bio'),);
				   $this->db->insert('registration_form',$data);
				   redirect('Registration/index');
	 }
  
  }
?>  