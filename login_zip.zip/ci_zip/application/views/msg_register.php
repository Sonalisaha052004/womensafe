<?php
    echo "Welcome ".$name." ".$pass;
	echo "<br>";
	echo "Hobbies Includes ".$hobbies."<br>";
	echo "Preferred location".$ploc;
?>	