<?php
  echo "Required Value of x1=".$Srinjoyee;
?>  