<?php
    $img=array('src'=>'images/a.jpg','width'=>'100','height'=>'100');
	echo img($img);
	echo anchor('user_test/','Click here');
?>	