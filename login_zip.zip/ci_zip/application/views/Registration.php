<html>
   <head>
      <title>Registration</title>
	</head>
    <body>
	<form>
	<?php
      echo form_open('Registration_form/','post');?>
      <h3 style="color:blue">For Registration Please Fill the following Form</h3>
      <h4>Enter Name:</h4><input type="text" name="Enter Name" value="<?php echo set_value('Name');?>"/>
      <h4>Enter Password:</h4>
      <input type="password" name="Enter Password" value="<?php echo set_value('Password');?>"/>

      <h4>Enter Address:</h4>
      <input type="text" name="Enter Address" value="<?php echo set_value('Address');?>"/>
	  <br>
	  <br>

      <?php echo form_label('Gender:')."<br>";
      echo form_radio('gender','male',false).form_label('Male')."<br>";
      echo form_radio('gender','female',false).form_label('Female')."<br>";
      ?> <br><br>
	  <?php echo form_label('Course Applied For:')."<br>";
      echo form_checkbox('course_name','Visual Basic.Net',false).form_label('Visual Basic.Net')."<br>";
      echo form_checkbox('course_name','ASP.NET',false).form_label('ASP.NET')."<br>";
      echo form_checkbox('course_name','XML',false).form_label('XML')."<br>";
	  ?>
	  <?php
	  echo form_label('Center');
	  echo form_dropdown('center',array('option1'=>'MintoPark','option2'=>'murshidabad','option3'=>'kerala','option4'=>'kashmir'));
	  echo form_error('Center');
	  ?>
	  <br><br>
	  <?php
	  echo form_label('Add Bio-data');
	  echo form_input('bio',set_value('bio'));
	  echo form_upload('document');
	  ?>
	  <br> <br>
	  <div><input type="Submit" value="Save"/><input type="Submit" value="Clear"/></div>
	 <br> <br>
	 
	 Please visit our 
	  <?php echo anchor('register','web-site');?>for further details
</form>
</body>
</html>	