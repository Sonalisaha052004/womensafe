<?php
    echo form_open('User/login_check','post');
	echo form_label('Username:');
	echo form_input('user_name')."<br/>";
	echo form_label('password:');
	echo form_password('password')."<br/>";
	echo form_submit('btnl','Login');
?>	
	