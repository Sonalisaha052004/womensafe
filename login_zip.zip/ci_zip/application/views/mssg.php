<?php
  echo "Welcome ".$name." ".$pass;
?>