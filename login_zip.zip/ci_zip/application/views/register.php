<?php
   echo form_open_multipart('user_register/register_check','post');
   echo form_label('Username:');
   echo form_input('user_name')."<br/>";
   echo form_label('password:');
   echo form_password('password')."<br/>";
   echo form_radio('gender','Male',true).form_label('Male');
   echo form_radio('gender','Female',false).form_label('Female')."<br/>";
   echo form_label('Hobbies:');
   echo form_checkbox('Hobbies[]','Singing',false).form_label('Singing');
   echo form_checkbox('Hobbies[]','Dancing',true).form_label('Dancing');
   echo form_checkbox('Hobbies[]','Surfing Internet',true).form_label('Surfing')."<br/>";
   echo form_label('current location:');
   echo form_dropdown('loc',array("Kolkata"=>"kolkata","Mumbai"=>"mumbai","Delhi"=>"delhi","Chennai"=>"chennai"))."<br/>";
   echo form_label('Preferred Location:');
   echo form_multiselect('ploc[]',array("Kolkata"=>"kolkata","Mumbai"=>"mumbai","Delhi"=>"delhi"))."<br/>";
   echo form_label('Address:');
   echo form_textarea('add')."<br/>";
   echo form_label('Upload Image:');
   echo form_upload('img');
   echo form_submit('register','Register');
?>   
   
   