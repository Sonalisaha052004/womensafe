-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 17, 2023 at 05:38 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `database3`
--

-- --------------------------------------------------------

--
-- Table structure for table `registration_form`
--

CREATE TABLE IF NOT EXISTS `registration_form` (
  `Name` varchar(30) DEFAULT NULL,
  `Password` varchar(40) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `gender` char(40) DEFAULT NULL,
  `course_name` char(40) DEFAULT NULL,
  `Center` char(50) DEFAULT NULL,
  `bio` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `salesman_master`
--

CREATE TABLE IF NOT EXISTS `salesman_master` (
  `SalesmanNo` varchar(6) DEFAULT NULL,
  `SalesmanName` varchar(20) DEFAULT NULL,
  `Address1` varchar(30) DEFAULT NULL,
  `Address2` varchar(30) DEFAULT NULL,
  `City` varchar(20) DEFAULT NULL,
  `PinCode` int(8) DEFAULT NULL,
  `State` varchar(20) DEFAULT NULL,
  `SalAmt` decimal(8,2) DEFAULT NULL,
  `TgtToGet` decimal(6,2) DEFAULT NULL,
  `YtdSales` decimal(6,2) DEFAULT NULL,
  `Remarks` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salesman_master`
--

INSERT INTO `salesman_master` (`SalesmanNo`, `SalesmanName`, `Address1`, `Address2`, `City`, `PinCode`, `State`, `SalAmt`, `TgtToGet`, `YtdSales`, `Remarks`) VALUES
('S01', 'Srinjoyee', 'kalighat', 'Bardhaman', 'Kolkata', 700070, 'WestBengal', '8000.20', '9999.99', '9999.99', 'Nice'),
('S02', 'Sayandeepta', 'Sonarpur', 'Hoogly', 'Kolkata', 700040, 'WestBengal', '8050.20', '9999.99', '4120.32', 'good'),
('S03', 'Hrithik', 'Shyambazar', 'Howrah', 'Kolkata', 700030, 'WestBengal', '800.20', '420.32', '9999.99', 'worse'),
('S04', 'Sourik', 'kudghat', 'Howrah', 'Kolkata', 700030, 'WestBengal', '40100.20', '5220.32', '1500.64', 'bad');

-- --------------------------------------------------------

--
-- Table structure for table `sales_order`
--

CREATE TABLE IF NOT EXISTS `sales_order` (
  `OrderNo` varchar(6) DEFAULT NULL,
  `ClientNo` varchar(6) DEFAULT NULL,
  `OrderDate` date DEFAULT NULL,
  `DelyAddr` varchar(25) DEFAULT NULL,
  `SalesmanNo` varchar(6) DEFAULT NULL,
  `DelyType` char(1) DEFAULT NULL,
  `Billed` char(1) DEFAULT NULL,
  `DelyDate` date DEFAULT NULL,
  `OrderStatus` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_order`
--

INSERT INTO `sales_order` (`OrderNo`, `ClientNo`, `OrderDate`, `DelyAddr`, `SalesmanNo`, `DelyType`, `Billed`, `DelyDate`, `OrderStatus`) VALUES
('o01', 'C01', '0000-00-00', 'D01', 'S01', 'O', 'C', '0000-00-00', 'Bus'),
('o02', 'C02', '0000-00-00', 'D02', 'S02', 'O', 'C', '0000-00-00', 'Car'),
('o03', 'C03', '0000-00-00', 'D03', 'S03', 'O', 'C', '0000-00-00', 'Car'),
('o04', 'C04', '0000-00-00', 'D04', 'S04', 'O', 'C', '0000-00-00', 'Car');

-- --------------------------------------------------------

--
-- Table structure for table `sales_order_details`
--

CREATE TABLE IF NOT EXISTS `sales_order_details` (
  `OrderNo` varchar(6) DEFAULT NULL,
  `ProductNo` varchar(6) DEFAULT NULL,
  `QtyOrdered` int(8) DEFAULT NULL,
  `QtyDisp` int(6) DEFAULT NULL,
  `ProductRate` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_order_details`
--

INSERT INTO `sales_order_details` (`OrderNo`, `ProductNo`, `QtyOrdered`, `QtyDisp`, `ProductRate`) VALUES
('O01', 'P01', 50, 20, '4000.30'),
('O02', 'P02', 50, 40, '5000.30'),
('O03', 'P03', 40, 45, '5020.10'),
('O04', 'P04', 65, 85, '4020.70');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
